# Supabase Google Authentication Backend

A secure backend authentication service using Supabase and Google OAuth.

## Features

- Google OAuth integration through Supabase
- JWT token management
- Protected API routes
- Rate limiting and security middleware
- User profile management
- Token refresh functionality

## Setup

1. **Supabase Configuration**:
   - Click "Connect to Supabase" button in the top right
   - In your Supabase dashboard, go to Authentication → Providers
   - Enable Google provider
   - Add your Google OAuth credentials (Client ID and Client Secret)
   - Set authorized redirect URI: `http://localhost:3001/auth/callback`

2. **Google OAuth Setup**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing one
   - Enable Google+ API
   - Create OAuth 2.0 credentials
   - Add authorized redirect URIs:
     - `http://localhost:3001/auth/callback`
     - Your Supabase redirect URI (found in Supabase dashboard)

3. **Environment Variables**:
   The following environment variables are automatically configured when you connect to Supabase:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`

   Optional variables you can set:
   - `FRONTEND_URL` (default: http://localhost:3000)
   - `PORT` (default: 3001)

## API Endpoints

### Authentication Routes (`/auth`)

- `GET /auth/google` - Get Google OAuth URL
- `GET /auth/callback` - Handle OAuth callback
- `GET /auth/profile` - Get user profile (protected)
- `POST /auth/signout` - Sign out user
- `POST /auth/refresh` - Refresh access token
- `GET /auth/health` - Health check

### Protected Routes (`/api`)

- `GET /api/dashboard` - Dashboard data (protected)
- `GET /api/user-data` - User-specific data (protected)

### General Routes

- `GET /` - API information
- `GET /health` - Server health check

## Usage

### 1. Start the server
```bash
npm run dev
```

### 2. Initiate Google authentication from your frontend
```javascript
// Get Google OAuth URL
const response = await fetch('http://localhost:3001/auth/google');
const { authUrl } = await response.json();

// Redirect user to Google OAuth
window.location.href = authUrl;
```

### 3. Handle the callback in your frontend
After successful authentication, users will be redirected to your frontend with tokens:
```javascript
// Extract tokens from URL params
const urlParams = new URLSearchParams(window.location.search);
const accessToken = urlParams.get('access_token');
const refreshToken = urlParams.get('refresh_token');

// Store tokens securely (localStorage, sessionStorage, or cookies)
localStorage.setItem('access_token', accessToken);
localStorage.setItem('refresh_token', refreshToken);
```

### 4. Make authenticated requests
```javascript
// Include token in Authorization header
const response = await fetch('http://localhost:3001/api/dashboard', {
  headers: {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json'
  }
});
```

### 5. Refresh tokens when needed
```javascript
const refreshResponse = await fetch('http://localhost:3001/auth/refresh', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    refresh_token: refreshToken
  })
});

const { access_token: newAccessToken } = await refreshResponse.json();
```

## Security Features

- Helmet.js for security headers
- Rate limiting (100 requests per 15 minutes per IP)
- CORS configuration
- Input validation and sanitization
- JWT token validation
- Environment variable protection

## Development

- The server runs on port 3001 by default
- Use `npm run dev` for development with auto-restart
- Use `npm start` for production

## Frontend Integration

This backend is designed to work with any frontend framework. The authentication flow:

1. Frontend requests Google OAuth URL
2. User is redirected to Google for authentication
3. Google redirects back to `/auth/callback`
4. Backend processes the callback and redirects to frontend with tokens
5. Frontend extracts tokens and uses them for API requests

Make sure your frontend can handle URL parameters for token extraction after the OAuth callback.