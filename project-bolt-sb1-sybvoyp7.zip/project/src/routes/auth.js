import express from 'express';
import { 
  getAuthUrl, 
  handleCallback, 
  getProfile, 
  signOut, 
  refreshToken 
} from '../controllers/authController.js';
import { authenticateUser } from '../middleware/auth.js';

const router = express.Router();

// Get Google OAuth URL
router.get('/google', getAuthUrl);

// Handle OAuth callback
router.get('/callback', handleCallback);

// Get user profile (protected route)
router.get('/profile', authenticateUser, getProfile);

// Sign out user
router.post('/signout', signOut);

// Refresh access token
router.post('/refresh', refreshToken);

// Health check for auth routes
router.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    service: 'Authentication API',
    timestamp: new Date().toISOString()
  });
});

export default router;