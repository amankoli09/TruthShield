import express from 'express';
import { authenticateUser } from '../middleware/auth.js';

const router = express.Router();

// Example protected route
router.get('/dashboard', authenticateUser, (req, res) => {
  res.json({
    message: 'Welcome to your dashboard!',
    user: {
      id: req.user.id,
      name: req.user.user_metadata?.full_name || req.user.user_metadata?.name,
    }
  });
});

// Example protected API endpoint
router.get('/user-data', authenticateUser, async (req, res) => {
  try {
    // Here you could fetch user-specific data from your database
    res.json({
      message: 'User-specific data',
      user_id: req.user.id,
      data: {
        // Add your user-specific data here
        preferences: {},
        settings: {},
        activity: []
      }
    });
  } catch (error) {
    console.error('Error fetching user data:', error);
    res.status(500).json({ 
      error: 'Failed to fetch user data' 
    });
  }
});

export default router;