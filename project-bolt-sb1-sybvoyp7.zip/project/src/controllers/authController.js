import { supabaseClient } from '../lib/supabase.js';

export const getAuthUrl = async (req, res) => {
  try {
    const { data, error } = await supabaseClient.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${req.protocol}://${req.get('host')}/auth/callback`,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });

    if (error) {
      return res.status(400).json({ 
        error: 'Failed to get Google auth URL',
        details: error.message 
      });
    }

    res.json({ 
      authUrl: data.url,
      message: 'Redirect user to this URL for Google authentication' 
    });
  } catch (error) {
    console.error('Google auth URL error:', error);
    res.status(500).json({ 
      error: 'Internal server error' 
    });
  }
};

export const handleCallback = async (req, res) => {
  try {
    const { code, error: authError } = req.query;

    if (authError) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=${encodeURIComponent(authError)}`);
    }

    if (!code) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=no_code`);
    }

    const { data, error } = await supabaseClient.auth.exchangeCodeForSession(code);

    if (error) {
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=${encodeURIComponent(error.message)}`);
    }

    // Successful authentication - redirect to frontend with session data
    const redirectUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}?access_token=${data.session.access_token}&refresh_token=${data.session.refresh_token}`;
    res.redirect(redirectUrl);
  } catch (error) {
    console.error('Auth callback error:', error);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=callback_error`);
  }
};

export const getProfile = async (req, res) => {
  try {
    const user = req.user;
    
    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.full_name || user.user_metadata?.name,
        avatar_url: user.user_metadata?.avatar_url,
        provider: user.app_metadata?.provider,
        created_at: user.created_at,
        last_sign_in: user.last_sign_in_at,
      }
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ 
      error: 'Failed to get user profile' 
    });
  }
};

export const signOut = async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      await supabaseClient.auth.admin.signOut(token);
    }

    res.json({ 
      message: 'Successfully signed out' 
    });
  } catch (error) {
    console.error('Sign out error:', error);
    res.status(500).json({ 
      error: 'Failed to sign out' 
    });
  }
};

export const refreshToken = async (req, res) => {
  try {
    const { refresh_token } = req.body;

    if (!refresh_token) {
      return res.status(400).json({ 
        error: 'Refresh token is required' 
      });
    }

    const { data, error } = await supabaseClient.auth.refreshSession({
      refresh_token
    });

    if (error) {
      return res.status(401).json({ 
        error: 'Invalid refresh token',
        details: error.message 
      });
    }

    res.json({
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_in: data.session.expires_in,
      user: data.user
    });
  } catch (error) {
    console.error('Token refresh error:', error);
    res.status(500).json({ 
      error: 'Failed to refresh token' 
    });
  }
};